<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;


class MajorCategory extends Entity
{

    protected $attributes = [
        'id'       => null,
        'name' => null,

    ];
}
