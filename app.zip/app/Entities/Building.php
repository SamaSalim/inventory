<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;

class Building extends Entity
{
    protected $attributes = [
        'id'       => null,
        'code'   => null,

    ];
}
