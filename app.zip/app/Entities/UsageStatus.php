<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;


class UsageStatus extends Entity
{

    protected $attributes = [
        'id'       => null,
        'usage_status' => null,

    ];
}
